STATUS_CHOICES = (
    ("New", "New"),
    ("In Progress", "In Progress"),
    ("Completed", "Completed")
)

PRIORITY_CHOICES = (
    ("Low", "Low"),
    ("Medium", "Medium"),
    ("High", "High")
)
