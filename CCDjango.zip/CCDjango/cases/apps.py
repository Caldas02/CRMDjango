from django.apps import AppConfig


class CasesConfig(AppConfig):
    name = 'cases'
