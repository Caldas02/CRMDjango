Leads
*****


.. image:: screenshots/leadshome1.png

|  **Fig** Accounts Home Page

|  The above figure shows the leads view, this page gives details and list view of leads
|  You can filter the results by name, source, assigned user, status, tags

|  Create a new Lead using the button on right corner ``+ Add New Lead``

.. image:: screenshots/leadscreate.png

|  **Fig** Leads Create Page

|  **Note:** Fields having ``*`` are mandatory
