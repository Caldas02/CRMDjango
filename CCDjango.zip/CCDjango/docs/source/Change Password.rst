Change Password
***************


.. image:: screenshots/changepassword.png

|  **Fig** Password Change Page

|  The above figure shows the password change view, here enter the old password in "old password field" and enter new password in "new password field" and retype the new password in "confirm new password" field.

|  Click "Change Password" button to change the password successfully, otherwise cancel to cancel the process.
